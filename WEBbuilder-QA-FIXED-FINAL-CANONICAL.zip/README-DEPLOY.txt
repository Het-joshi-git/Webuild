WEBbuilder — Vercel deployment

Upload this folder/ZIP to Vercel as a static site.
No build command is required.
The included vercel.json routes / to final.html and provides the production headers.
Keep Supabase setup SQL outside the public deployment.
After connecting the production domain, update the homepage canonical URL and add sitemap.xml with the real domain.
